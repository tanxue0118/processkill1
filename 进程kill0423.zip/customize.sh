SKIPUNZIP=0

# ==============================
# 继承开关
# 1=继承
# 0=不继承
# ==============================
INHERIT_LIST=1
INHERIT_CONFIG=1

# ==============================
# 附带模块(zip)配置
# ==============================
# 主模块zip内路径: addon/extra_module.zip
BUNDLE_ZIP_NAME="进程kill热重载.zip"
BUNDLE_ZIP_INNER_PATH="addon/$BUNDLE_ZIP_NAME"

TARGET_MODULE_ID="process_kill_watcher"

BUNDLE_TMP_DIR="$TMPDIR/pk_addon"
BUNDLE_TMP_ZIP="$BUNDLE_TMP_DIR/$BUNDLE_ZIP_NAME"

# ==============================
# Magisk专属附带APK配置
# ==============================
# 主模块zip内路径: app/helper.apk
BUNDLE_APP_NAME="KsuWebUI.apk"
BUNDLE_APP_INNER_PATH="app/$BUNDLE_APP_NAME"
BUNDLE_APP_PKG="io.github.a13e300.ksuwebui"   # 改成真实包名

APP_TMP_DIR="$TMPDIR/pk_app"
APP_TMP_APK="$APP_TMP_DIR/$BUNDLE_APP_NAME"

ui_print "=================================="
ui_print "Processkill 进程压制模块"
ui_print "=================================="
ui_print " "

ui_print "- 正在配置模块文件"
chmod 0755 "$MODPATH/service.sh"
chmod 0755 "$MODPATH/bin/jy"
[ -f "$MODPATH/bin/processkill" ] && chmod 0755 "$MODPATH/bin/processkill"
[ -f "$MODPATH/action2.sh" ] && chmod 0755 "$MODPATH/action2.sh"
chmod 0644 "$MODPATH/module.prop"
[ -f "$MODPATH/配置文件.txt" ] && chmod 0644 "$MODPATH/配置文件.txt"
[ -f "$MODPATH/黑白名单.txt" ] && chmod 0644 "$MODPATH/黑白名单.txt"
[ -d "$MODPATH/webroot" ] && chmod 0755 "$MODPATH/webroot"
[ -f "$MODPATH/webroot/index.html" ] && chmod 0644 "$MODPATH/webroot/index.html"
[ -f "$MODPATH/webroot/style.css" ] && chmod 0644 "$MODPATH/webroot/style.css"
[ -f "$MODPATH/webroot/app.js" ] && chmod 0644 "$MODPATH/webroot/app.js"

inherit_config() {
    OLD_MODDIR="/data/adb/modules/Process_Kill"
    NEW_MODDIR="$MODPATH"

    ui_print " "
    ui_print "╔══════════════════════════════════════╗"
    ui_print "║          配置文件检查与继承          ║"
    ui_print "╚══════════════════════════════════════╝"

    ui_print "⚙️ 当前继承策略："
    ui_print "   - 黑白名单继承: $INHERIT_LIST"
    ui_print "   - 配置文件继承: $INHERIT_CONFIG"

    if [ ! -d "$OLD_MODDIR" ]; then
        ui_print "ℹ️ 未检测到旧模块目录"
        ui_print "✅ 使用新模块内置默认配置"
        return 0
    fi

    inherited_count=0

    # 继承 黑白名单.txt
    if [ "$INHERIT_LIST" = "1" ]; then
        if [ -f "$OLD_MODDIR/黑白名单.txt" ]; then
            cp -af "$OLD_MODDIR/黑白名单.txt" "$NEW_MODDIR/黑白名单.txt" 2>/dev/null
            ui_print "✅ 已继承：黑白名单.txt"
            inherited_count=$((inherited_count + 1))
        else
            ui_print "📝 旧版无 黑白名单.txt，保留新默认名单"
        fi
    else
        ui_print "⏭️ 已关闭 黑白名单.txt 继承，使用新模块内置名单"
    fi

    # 继承 配置文件.txt
    if [ "$INHERIT_CONFIG" = "1" ]; then
        if [ -f "$OLD_MODDIR/配置文件.txt" ]; then
            cp -af "$OLD_MODDIR/配置文件.txt" "$NEW_MODDIR/配置文件.txt" 2>/dev/null
            ui_print "✅ 已继承：配置文件.txt"
            inherited_count=$((inherited_count + 1))
        else
            ui_print "📝 旧版无 配置文件.txt，保留新默认配置"
        fi
    else
        ui_print "⏭️ 已关闭 配置文件.txt 继承，使用新模块内置默认配置"
    fi

    if [ "$inherited_count" -eq 0 ]; then
        ui_print "✅ 本次未继承旧配置文件"
    else
        ui_print "🎉 配置继承完成（共 $inherited_count 项）"
    fi
}

# 检测模块是否已安装
is_module_installed() {
    local id="$1"
    [ -d "/data/adb/modules/$id" ] && return 0
    [ -d "/data/adb/modules_update/$id" ] && return 0
    return 1
}

# 尝试安装附带zip（多通道）
try_install_bundle_zip() {
    local zip="$1"

    # KernelSU 通道
    if command -v ksud >/dev/null 2>&1; then
        ksud module install "$zip" >/dev/null 2>&1 && return 0
    fi

    # Magisk 通道
    if command -v magisk >/dev/null 2>&1; then
        magisk --install-module "$zip" >/dev/null 2>&1 && return 0
    fi

    return 1
}

# 附带模块zip：存在则不装，不存在则安装，最后删包
install_bundled_module_if_needed() {
    ui_print " "
    ui_print "╔══════════════════════════════════════╗"
    ui_print "║         附带模块检测与处理           ║"
    ui_print "╚══════════════════════════════════════╝"

    rm -rf "$BUNDLE_TMP_DIR" 2>/dev/null
    mkdir -p "$BUNDLE_TMP_DIR"

    unzip -o "$ZIPFILE" "$BUNDLE_ZIP_INNER_PATH" -d "$BUNDLE_TMP_DIR" >/dev/null 2>&1
    if [ ! -f "$BUNDLE_TMP_ZIP" ]; then
        ui_print "ℹ️ 未找到附带模块包：$BUNDLE_ZIP_INNER_PATH"
        ui_print "⏭️ 跳过附带模块安装"
        rm -rf "$BUNDLE_TMP_DIR" 2>/dev/null
        return 0
    fi

    ui_print "📦 检测目标模块：$TARGET_MODULE_ID"

    if is_module_installed "$TARGET_MODULE_ID"; then
        ui_print "✅ 已检测到目标模块，跳过安装"
        rm -f "$BUNDLE_TMP_ZIP" 2>/dev/null
        rm -rf "$BUNDLE_TMP_DIR" 2>/dev/null
        ui_print "🧹 已清理附带模块安装包"
        return 0
    fi

    ui_print "🔧 未检测到目标模块，开始安装附带模块..."
    if try_install_bundle_zip "$BUNDLE_TMP_ZIP"; then
        ui_print "🎉 附带模块安装命令执行成功"
    else
        ui_print "⚠️ 附带模块安装失败（不影响主模块安装）"
    fi

    if is_module_installed "$TARGET_MODULE_ID"; then
        ui_print "✅ 目标模块已就位"
    else
        ui_print "⚠️ 目标模块仍未检测到，可能需手动安装"
    fi

    rm -f "$BUNDLE_TMP_ZIP" 2>/dev/null
    rm -rf "$BUNDLE_TMP_DIR" 2>/dev/null
    ui_print "🧹 已清理附带模块安装包"
}

# 仅Magisk处理APK：非Magisk跳过；已装则不装；最后删包
install_magisk_only_app_if_needed() {
    ui_print " "
    ui_print "╔══════════════════════════════════════╗"
    ui_print "║       Magisk 专属附带软件处理         ║"
    ui_print "╚══════════════════════════════════════╝"

    # 非Magisk直接跳过
    if ! command -v magisk >/dev/null 2>&1; then
        ui_print "ℹ️ 当前非 Magisk 环境，跳过附带软件安装"
        rm -rf "$APP_TMP_DIR" 2>/dev/null
        return 0
    fi

    ui_print "✅ 检测到 Magisk 环境"

    rm -rf "$APP_TMP_DIR" 2>/dev/null
    mkdir -p "$APP_TMP_DIR"

    unzip -o "$ZIPFILE" "$BUNDLE_APP_INNER_PATH" -d "$APP_TMP_DIR" >/dev/null 2>&1
    if [ ! -f "$APP_TMP_APK" ]; then
        ui_print "ℹ️ 未找到附带软件包：$BUNDLE_APP_INNER_PATH"
        ui_print "⏭️ 跳过安装"
        rm -rf "$APP_TMP_DIR" 2>/dev/null
        return 0
    fi

    # 检测包是否已安装
    if pm list packages 2>/dev/null | grep -q "^package:$BUNDLE_APP_PKG$"; then
        ui_print "✅ 已安装 $BUNDLE_APP_PKG ，跳过安装"
    else
        ui_print "🔧 未安装 $BUNDLE_APP_PKG ，开始安装..."
        if pm install -r "$APP_TMP_APK" >/dev/null 2>&1; then
            ui_print "🎉 软件安装成功"
        else
            ui_print "⚠️ 软件安装失败（不影响主模块安装）"
        fi
    fi

    # 无论是否安装都删除安装包
    rm -f "$APP_TMP_APK" 2>/dev/null
    rm -rf "$APP_TMP_DIR" 2>/dev/null
    ui_print "🧹 已删除附带软件安装包"
}

inherit_config
install_bundled_module_if_needed
install_magisk_only_app_if_needed

ui_print " "
ui_print "✅ 模块刷入完成！"
ui_print "请重启手机生效"
ui_print "=================================="

ui_print "🔄 正在跳转酷安主页..."
(am start -d 'coolmarket://u/29109774' >/dev/null 2>&1) &
ui_print "❤️ 感谢您的支持！"
