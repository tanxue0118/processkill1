let exec = null;
let toastNative = (msg)=>console.log(msg);

const MOD = '/data/adb/modules/Process_Kill';
const CONFIG = `${MOD}/配置文件.txt`;
const LIST = `${MOD}/黑白名单.txt`;
const LOG = `${MOD}/日志.log`;
const STATS = `${MOD}/压制统计.txt`;

const UI_SETTINGS_KEY = 'process_kill_ui_settings';

function getCurrentDir(){
  if (document.currentScript && document.currentScript.src) {
    return document.currentScript.src.substring(0, document.currentScript.src.lastIndexOf('/') + 1);
  }

  const scripts = document.getElementsByTagName('script');
  for (let i = scripts.length - 1; i >= 0; i--) {
    const src = scripts[i].src || '';
    if (src.includes('app.js')) {
      return src.substring(0, src.lastIndexOf('/') + 1);
    }
  }

  return './';
}

const BASE_DIR = getCurrentDir();
const BG_CANDIDATES = [
  `${BASE_DIR}background.jpg`,
  `${BASE_DIR}background.jpeg`,
  `${BASE_DIR}background.png`,
  `${BASE_DIR}background.webp`
];

let statusTimer = null;
let logTimer = null;
let configSaveTimer = null;
let suppressConfigAutoSave = false;

const defaultUiSettings = {
  panelBlur: 20,
  theme: 'light'
};

function loadUiSettings(){
  try {
    const raw = localStorage.getItem(UI_SETTINGS_KEY);
    if (!raw) return { ...defaultUiSettings };
    const data = JSON.parse(raw);
    return {
      panelBlur: Number.isFinite(Number(data.panelBlur)) ? Number(data.panelBlur) : defaultUiSettings.panelBlur,
      theme: data.theme === 'dark' ? 'dark' : 'light'
    };
  } catch (e) {
    console.error('loadUiSettings failed', e);
    return { ...defaultUiSettings };
  }
}

let uiSettings = loadUiSettings();

function saveUiSettings(){
  try {
    localStorage.setItem(UI_SETTINGS_KEY, JSON.stringify(uiSettings));
  } catch (e) {
    console.error('saveUiSettings failed', e);
  }
}

function initKsu() {
  if (typeof window.ksu !== 'undefined' && window.ksu.exec) {
    exec = (cmd) => new Promise((resolve, reject) => {
      const cb = 'cb_' + Date.now() + '_' + Math.floor(Math.random() * 9999);
      window[cb] = (errno, stdout, stderr) => {
        resolve({ errno, stdout, stderr });
        delete window[cb];
      };
      try {
        window.ksu.exec(cmd, "{}", cb);
      } catch (e) {
        delete window[cb];
        reject(e);
      }
    });

    toastNative = (msg) => {
      try { window.ksu.toast(msg); } catch (e) {}
    };
  } else {
    exec = async () => ({ errno: 1, stdout: '', stderr: 'ksu bridge unavailable' });
  }
}

function toast(msg){
  const el = document.getElementById('toast');
  if (!el) return;
  el.textContent = msg;
  el.classList.add('show');
  toastNative(msg);
  clearTimeout(el._timer);
  el._timer = setTimeout(() => el.classList.remove('show'), 1800);
}

async function sh(cmd){
  return await exec(cmd);
}

async function shOut(cmd){
  const { stdout } = await sh(cmd);
  return stdout || '';
}

function isNearBottom(el, threshold = 48){
  return (el.scrollHeight - el.scrollTop - el.clientHeight) < threshold;
}

function setRunStatus(running){
  const dot = document.getElementById('runDot');
  const text = document.getElementById('runText');
  if (!dot || !text) return;

  if (running) {
    dot.className = 'dot ok';
    text.textContent = '运行中';
  } else {
    dot.className = 'dot fail';
    text.textContent = '未运行';
  }
}

function setBar(id, percent){
  const el = document.getElementById(id);
  if (!el) return;
  const p = Math.max(0, Math.min(100, Number(percent) || 0));
  el.style.width = `${p}%`;
}

function kbToMb(kb){
  const n = Number(kb) || 0;
  return Math.round(n / 1024);
}

async function readFile(path){
  const { errno, stdout } = await sh(`cat '${path}' 2>/dev/null`);
  return errno === 0 ? stdout : '';
}

async function writeFile(path, content){
  const { errno, stderr } = await sh(`cat > '${path}' <<'EOF'
${content}
EOF
chmod 0644 '${path}'`);
  if (errno !== 0) throw new Error(stderr || 'write failed');
}

async function clearFile(path){
  const { errno, stderr } = await sh(`: > '${path}'`);
  if (errno !== 0) throw new Error(stderr || 'clear failed');
}

function applyPanelBlur(value, save = true){
  const blurSlider = document.getElementById('blurSlider');
  const blurValue = document.getElementById('blurValue');

  const blur = Math.max(0, Math.min(40, Number(value) || 0));

  document.documentElement.style.setProperty('--glass-blur', `${blur}px`);
  document.documentElement.style.setProperty('--glass-inner-blur', `${Math.max(0, Math.round(blur * 0.7))}px`);
  document.documentElement.style.setProperty('--field-blur', `${Math.max(0, Math.round(blur * 0.6))}px`);
  document.documentElement.style.setProperty('--nav-blur', `${Math.max(0, Math.round(blur * 1.1))}px`);

  if (blurSlider) blurSlider.value = blur;
  if (blurValue) blurValue.textContent = `${blur}px`;

  uiSettings.panelBlur = blur;
  if (save) saveUiSettings();
}

function applyTheme(theme, save = true){
  const body = document.body;
  const themeToggle = document.getElementById('themeToggle');
  const themeLabel = document.getElementById('themeLabel');
  const finalTheme = theme === 'dark' ? 'dark' : 'light';

  if (body) body.classList.toggle('dark-mode', finalTheme === 'dark');
  if (themeToggle) themeToggle.checked = finalTheme === 'dark';
  if (themeLabel) themeLabel.textContent = finalTheme === 'dark' ? '深色模式' : '浅色模式';

  uiSettings.theme = finalTheme;
  if (save) saveUiSettings();
}

function restoreUiSettings(){
  applyPanelBlur(uiSettings.panelBlur, false);
  applyTheme(uiSettings.theme, false);
}

function initUiControls(){
  const blurSlider = document.getElementById('blurSlider');
  const themeToggle = document.getElementById('themeToggle');

  if (blurSlider) {
    blurSlider.addEventListener('input', (e) => {
      applyPanelBlur(e.target.value, true);
    });
  }

  if (themeToggle) {
    themeToggle.addEventListener('change', (e) => {
      applyTheme(e.target.checked ? 'dark' : 'light', true);
    });
  }
}

function loadBackgroundImage(){
  const bg = document.getElementById('bgLayer');
  if (!bg) return false;

  let index = 0;

  const tryNext = () => {
    if (index >= BG_CANDIDATES.length) {
      console.warn('未找到 background 图片');
      bg.style.backgroundImage = 'none';
      return false;
    }

    const url = BG_CANDIDATES[index++];
    const img = new Image();

    img.onload = () => {
      bg.style.backgroundImage = `url("${url}")`;
    };

    img.onerror = () => {
      tryNext();
    };

    img.src = url;
  };

  tryNext();
  return true;
}

/* 配置文件：解析 / 表单 / 自动保存 */
function parseConfigText(text){
  const result = {};
  const lines = String(text || '').split('\n');

  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;

    const eq = line.indexOf('=');
    if (eq <= 0) continue;

    const key = line.slice(0, eq).trim();
    const value = line.slice(eq + 1).trim();
    result[key] = value;
  }
  return result;
}

function boolFromConfig(value, defaultValue = false){
  if (String(value).trim() === '1') return true;
  if (String(value).trim() === '0') return false;
  return defaultValue;
}

function setSwitchWithLabel(inputId, labelId, checked, onText = '开启', offText = '关闭'){
  const input = document.getElementById(inputId);
  const label = document.getElementById(labelId);
  if (input) input.checked = !!checked;
  if (label) label.textContent = checked ? onText : offText;
}

function bindConfigSwitchLabel(inputId, labelId, onText = '开启', offText = '关闭'){
  const input = document.getElementById(inputId);
  const label = document.getElementById(labelId);
  if (!input || !label) return;

  const update = () => {
    label.textContent = input.checked ? onText : offText;
  };

  input.addEventListener('change', update);
  update();
}

function normalizeInt(value, fallback, min = null){
  let n = parseInt(String(value ?? '').trim(), 10);
  if (!Number.isFinite(n)) n = fallback;
  if (min !== null && n < min) n = min;
  return n;
}

function buildConfigText(){
  const oom_threshold = normalizeInt(document.getElementById('cfg_oom_threshold')?.value, 800, 0);
  const deep_press = document.getElementById('cfg_deep_press')?.checked ? '1' : '0';
  const poll_interval = normalizeInt(document.getElementById('cfg_poll_interval')?.value, 15, 10);
  const log_max_lines = normalizeInt(document.getElementById('cfg_log_max_lines')?.value, 100, 1);
  const verbose_kill_log = document.getElementById('cfg_verbose_kill_log')?.checked ? '1' : '0';
  const protect_foreground = document.getElementById('cfg_protect_foreground')?.checked ? '1' : '0';
  const 通知 = document.getElementById('cfg_notify')?.checked ? '1' : '0';

  return `# oom调节（建议800，调得越低压制越激进）
oom_threshold=${oom_threshold}
# 深度压制：1=杀所有符合条件的进程，0=只杀子进程（推荐）
deep_press=${deep_press}
# 轮询间隔（秒，最低10）
poll_interval=${poll_interval}
# 日志最大行数
log_max_lines=${log_max_lines}
# 是否记录每个被杀进程明细：1=开，0=关（建议关，省IO）
verbose_kill_log=${verbose_kill_log}
# 是否保护前台应用：1=保护，0=不保护（关闭更省一点，但可能误杀前台）
protect_foreground=${protect_foreground}
# 是否启用通知：1=开，0=关
通知=${通知}
`;
}

function fillConfigForm(cfg){
  suppressConfigAutoSave = true;

  document.getElementById('cfg_oom_threshold').value = cfg.oom_threshold ?? '800';
  document.getElementById('cfg_poll_interval').value = cfg.poll_interval ?? '15';
  document.getElementById('cfg_log_max_lines').value = cfg.log_max_lines ?? '100';

  setSwitchWithLabel('cfg_deep_press', 'label_deep_press', boolFromConfig(cfg.deep_press, false), '开启', '关闭');
  setSwitchWithLabel('cfg_verbose_kill_log', 'label_verbose_kill_log', boolFromConfig(cfg.verbose_kill_log, false), '开启', '关闭');
  setSwitchWithLabel('cfg_protect_foreground', 'label_protect_foreground', boolFromConfig(cfg.protect_foreground, true), '开启', '关闭');
  setSwitchWithLabel('cfg_notify', 'label_notify', boolFromConfig(cfg['通知'], true), '开启', '关闭');

  suppressConfigAutoSave = false;
}

async function saveConfigImmediate(showToast = false){
  try{
    const content = buildConfigText();
    await writeFile(CONFIG, content);
    if (showToast) toast('配置已保存');
  }catch(e){
    console.error(e);
    toast('保存配置失败');
  }
}

function scheduleConfigSave(){
  if (suppressConfigAutoSave) return;

  clearTimeout(configSaveTimer);
  configSaveTimer = setTimeout(() => {
    saveConfigImmediate(false);
  }, 250);
}

function initConfigForm(){
  bindConfigSwitchLabel('cfg_deep_press', 'label_deep_press', '开启', '关闭');
  bindConfigSwitchLabel('cfg_verbose_kill_log', 'label_verbose_kill_log', '开启', '关闭');
  bindConfigSwitchLabel('cfg_protect_foreground', 'label_protect_foreground', '开启', '关闭');
  bindConfigSwitchLabel('cfg_notify', 'label_notify', '开启', '关闭');

  const ids = [
    'cfg_oom_threshold',
    'cfg_poll_interval',
    'cfg_log_max_lines',
    'cfg_deep_press',
    'cfg_verbose_kill_log',
    'cfg_protect_foreground',
    'cfg_notify'
  ];

  ids.forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;

    const eventName = el.type === 'checkbox' ? 'change' : 'input';
    el.addEventListener(eventName, () => {
      scheduleConfigSave();
    });

    if (el.type !== 'checkbox') {
      el.addEventListener('change', () => {
        scheduleConfigSave();
      });
    }
  });
}

async function loadConfig(){
  const text = await readFile(CONFIG);
  const cfg = parseConfigText(text);
  fillConfigForm(cfg);
}

async function loadStatus(){
  const runningText = await shOut(`ps -A 2>/dev/null | grep processkill | grep -v grep >/dev/null && echo 1 || echo 0`);
  const running = String(runningText).trim() === '1';
  setRunStatus(running);

  const total = await shOut(`cat '${STATS}' 2>/dev/null || echo 0`);
  document.getElementById('totalKill').textContent = (String(total).trim() || '0');

  const memRaw = await shOut(`
MT=$(awk '/MemTotal:/ {print $2}' /proc/meminfo)
MA=$(awk '/MemAvailable:/ {print $2}' /proc/meminfo)
SU=$(awk '/SwapTotal:/ {print $2}' /proc/meminfo)
SF=$(awk '/SwapFree:/ {print $2}' /proc/meminfo)

[ -z "$MT" ] && MT=0
[ -z "$MA" ] && MA=0
[ -z "$SU" ] && SU=0
[ -z "$SF" ] && SF=0

MU=$((MT - MA))
[ "$MU" -lt 0 ] && MU=0

SWU=$((SU - SF))
[ "$SWU" -lt 0 ] && SWU=0

if [ "$MT" -gt 0 ]; then
  MP=$((MU * 100 / MT))
else
  MP=0
fi

if [ "$SU" -gt 0 ]; then
  SP=$((SWU * 100 / SU))
else
  SP=0
fi

echo "$MT|$MU|$MP|$SU|$SWU|$SP"
`);

  const [mt, mu, mp, su, swu, sp] = String(memRaw).trim().split('|').map(v => parseInt(v || '0', 10));

  document.getElementById('memPercent').textContent = `${mp || 0}%`;
  document.getElementById('swapPercent').textContent = `${sp || 0}%`;
  document.getElementById('memUsageText').textContent = `${kbToMb(mu)} MB / ${kbToMb(mt)} MB`;
  document.getElementById('swapUsageText').textContent = `${kbToMb(swu)} MB / ${kbToMb(su)} MB`;

  setBar('memBar', mp || 0);
  setBar('swapBar', sp || 0);
}

async function loadList(){
  document.getElementById('listBox').value = await readFile(LIST);
}

async function loadLog(auto = false){
  const lines = parseInt(document.getElementById('logLines').value || '200', 10);
  const box = document.getElementById('logBox');
  const shouldStickBottom = isNearBottom(box);

  const text = await shOut(`tail -n ${lines} '${LOG}' 2>/dev/null`);
  box.textContent = text || '';

  if (!auto || shouldStickBottom) {
    box.scrollTop = box.scrollHeight;
  }
}

async function saveList(){
  try{
    const content = document.getElementById('listBox').value || '';
    await writeFile(LIST, content);
    toast('黑白名单已保存');
  }catch(e){
    console.error(e);
    toast('保存名单失败');
  }
}

async function clearLog(){
  try{
    await clearFile(LOG);
    document.getElementById('logBox').textContent = '';
    toast('日志已清空');
  }catch(e){
    console.error(e);
    toast('清空日志失败');
  }
}

async function refreshAll(){
  try{
    restoreUiSettings();
    loadBackgroundImage();
    await Promise.all([
      loadStatus(),
      loadConfig(),
      loadList(),
      loadLog(false)
    ]);
  }catch(e){
    console.error(e);
    toast('刷新失败');
  }
}

function startAutoRefresh(){
  stopAutoRefresh();

  statusTimer = setInterval(() => {
    loadStatus().catch(console.error);
  }, 5000);

  logTimer = setInterval(() => {
    const logPage = document.getElementById('logPage');
    if (logPage && logPage.classList.contains('active')) {
      loadLog(true).catch(console.error);
    }
  }, 3000);
}

function stopAutoRefresh(){
  if (statusTimer) {
    clearInterval(statusTimer);
    statusTimer = null;
  }
  if (logTimer) {
    clearInterval(logTimer);
    logTimer = null;
  }
}

function initBottomNav(){
  const items = document.querySelectorAll('.nav-item');
  const pages = document.querySelectorAll('.page');

  items.forEach(item => {
    item.addEventListener('click', async () => {
      const target = item.dataset.page;

      items.forEach(btn => btn.classList.remove('active'));
      pages.forEach(page => page.classList.remove('active'));

      item.classList.add('active');
      const page = document.getElementById(target);
      if (page) page.classList.add('active');

      if (target === 'statusPage') {
        await loadStatus().catch(console.error);
      } else if (target === 'logPage') {
        await loadLog(false).catch(console.error);
      } else if (target === 'settingsPage') {
        await loadConfig().catch(console.error);
        await loadList().catch(console.error);
      }
    });
  });
}

document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    stopAutoRefresh();
  } else {
    loadStatus().catch(console.error);
    loadLog(true).catch(console.error);
    startAutoRefresh();
  }
});

initKsu();
restoreUiSettings();

document.getElementById('refreshAllBtn').addEventListener('click', async () => {
  await refreshAll();
  toast('已刷新');
});

document.getElementById('saveListBtn').addEventListener('click', saveList);
document.getElementById('reloadLogBtn').addEventListener('click', () => loadLog(false));
document.getElementById('clearLogBtn').addEventListener('click', clearLog);

initUiControls();
initConfigForm();
initBottomNav();

refreshAll().then(() => {
  startAutoRefresh();
});
