#!/system/bin/sh

MODDIR=${0%/*}
MAIN_BIN="$MODDIR/bin/jy"
PK_BIN="$MODDIR/bin/processkill"
CONFIG_FILE="$MODDIR/配置文件.txt"
WHITELIST_FILE="$MODDIR/黑白名单.txt"
LOG_FILE="$MODDIR/日志.log"

[ -f "$MAIN_BIN" ] || exit 0

chmod 0755 "$MAIN_BIN" 2>/dev/null
[ -f "$PK_BIN" ] && chmod 0755 "$PK_BIN" 2>/dev/null
[ -f "$MODDIR/action2.sh" ] && chmod 0755 "$MODDIR/action2.sh" 2>/dev/null
[ -f "$CONFIG_FILE" ] && chmod 0644 "$CONFIG_FILE" 2>/dev/null
[ -f "$WHITELIST_FILE" ] && chmod 0644 "$WHITELIST_FILE" 2>/dev/null

touch "$LOG_FILE" 2>/dev/null
chmod 0644 "$LOG_FILE" 2>/dev/null

echo "$(date '+%H:%M:%S') 正在检验" >> "$LOG_FILE"

NOTIFY_ENABLE=0

if [ -f "$CONFIG_FILE" ]; then
    while IFS= read -r line; do
        line=$(echo "$line" | tr -d '\r' | cut -d'#' -f1 | xargs)
        [ -z "$line" ] && continue
        case "$line" in
            通知=*) NOTIFY_ENABLE=${line#*=} ;;
        esac
    done < "$CONFIG_FILE"
fi

sleep 60

"$MAIN_BIN" &

sleep 2

if [ "$NOTIFY_ENABLE" = "1" ] && [ -f "$MODDIR/action2.sh" ]; then
    sh "$MODDIR/action2.sh" &
fi

exit 0
