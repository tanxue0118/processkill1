#!/system/bin/sh

MODDIR=${0%/*}
CONFIG_FILE="$MODDIR/配置文件.txt"

# 读取配置里的 通知=1 或 0
NOTIFY_ENABLE=0
if [ -f "$CONFIG_FILE" ]; then
    while IFS= read -r line; do
        line=$(echo "$line" | tr -d '\r' | cut -d'#' -f1 | xargs)
        [ -z "$line" ] && continue
        case "$line" in
            通知=*) NOTIFY_ENABLE=${line#*=} ;;
        esac
    done < "$CONFIG_FILE"
fi

[ "$NOTIFY_ENABLE" != "1" ] && exit 0

{
    # 1) 正在检验
    su 2000 -c "cmd notification post -S messaging \
        --conversation 'ProcessKill' \
        --message 'ProcessKill:🔄 正在检验' \
        'Tag' '$RANDOM'" >/dev/null 2>&1

    # 2) 立即检验 processkill
    PROCESS_NAME="processkill"
    IS_RUNNING=false
    pidof "$PROCESS_NAME" >/dev/null 2>&1 && IS_RUNNING=true

    if [ "$IS_RUNNING" = true ]; then
        su 2000 -c "cmd notification post -S messaging \
            --conversation 'ProcessKill' \
            --message 'ProcessKill:✅ 检验成功' \
            'Tag' '$RANDOM'" >/dev/null 2>&1
    else
        su 2000 -c "cmd notification post -S messaging \
            --conversation 'ProcessKill' \
            --message 'ProcessKill:❌ 检验失败' \
            'Tag' '$RANDOM'" >/dev/null 2>&1
    fi

    # 3) 等30秒后再次检验
    sleep 30

    IS_RUNNING=false
    pidof "$PROCESS_NAME" >/dev/null 2>&1 && IS_RUNNING=true
    if [ "$IS_RUNNING" = true ]; then
        su 2000 -c "cmd notification post -S messaging \
            --conversation 'ProcessKill' \
            --message 'ProcessKill:✅ 正在运行' \
            'Tag' '$RANDOM'" >/dev/null 2>&1
    else
        su 2000 -c "cmd notification post -S messaging \
            --conversation 'ProcessKill' \
            --message 'ProcessKill:❌ 未运行或已异常退出' \
            'Tag' '$RANDOM'" >/dev/null 2>&1
    fi

} &

exit 0
