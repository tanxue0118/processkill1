SKIPUNZIP=0

# ==============================
# 继承开关
# 1=继承
# 0=不继承
# ==============================
INHERIT_LIST=1
INHERIT_CONFIG=1

ui_print "=================================="
ui_print "Processkill 进程压制模块"
ui_print "=================================="
ui_print " "

ui_print "- 正在配置模块文件"
chmod 0755 "$MODPATH/service.sh"
chmod 0755 "$MODPATH/bin/jy"
[ -f "$MODPATH/bin/processkill" ] && chmod 0755 "$MODPATH/bin/processkill"
[ -f "$MODPATH/action2.sh" ] && chmod 0755 "$MODPATH/action2.sh"
chmod 0644 "$MODPATH/module.prop"
[ -f "$MODPATH/配置文件.txt" ] && chmod 0644 "$MODPATH/配置文件.txt"
[ -f "$MODPATH/黑白名单.txt" ] && chmod 0644 "$MODPATH/黑白名单.txt"
[ -d "$MODPATH/webroot" ] && chmod 0755 "$MODPATH/webroot"
[ -f "$MODPATH/webroot/index.html" ] && chmod 0644 "$MODPATH/webroot/index.html"
[ -f "$MODPATH/webroot/style.css" ] && chmod 0644 "$MODPATH/webroot/style.css"
[ -f "$MODPATH/webroot/app.js" ] && chmod 0644 "$MODPATH/webroot/app.js"
inherit_config() {
    OLD_MODDIR="/data/adb/modules/Process_Kill"
    NEW_MODDIR="$MODPATH"

    ui_print " "
    ui_print "╔══════════════════════════════════════╗"
    ui_print "║          配置文件检查与继承          ║"
    ui_print "╚══════════════════════════════════════╝"

    ui_print "⚙️ 当前继承策略："
    ui_print "   - 黑白名单继承: $INHERIT_LIST"
    ui_print "   - 配置文件继承: $INHERIT_CONFIG"

    if [ ! -d "$OLD_MODDIR" ]; then
        ui_print "ℹ️ 未检测到旧模块目录"
        ui_print "✅ 使用新模块内置默认配置"
        return 0
    fi

    inherited_count=0

    # 继承 黑白名单.txt
    if [ "$INHERIT_LIST" = "1" ]; then
        if [ -f "$OLD_MODDIR/黑白名单.txt" ]; then
            cp -af "$OLD_MODDIR/黑白名单.txt" "$NEW_MODDIR/黑白名单.txt" 2>/dev/null
            ui_print "✅ 已继承：黑白名单.txt"
            inherited_count=$((inherited_count + 1))
        else
            ui_print "📝 旧版无 黑白名单.txt，保留新默认名单"
        fi
    else
        ui_print "⏭️ 已关闭 黑白名单.txt 继承，使用新模块内置名单"
    fi

    # 继承 配置文件.txt
    if [ "$INHERIT_CONFIG" = "1" ]; then
        if [ -f "$OLD_MODDIR/配置文件.txt" ]; then
            cp -af "$OLD_MODDIR/配置文件.txt" "$NEW_MODDIR/配置文件.txt" 2>/dev/null
            ui_print "✅ 已继承：配置文件.txt"
            inherited_count=$((inherited_count + 1))
        else
            ui_print "📝 旧版无 配置文件.txt，保留新默认配置"
        fi
    else
        ui_print "⏭️ 已关闭 配置文件.txt 继承，使用新模块内置默认配置"
    fi

    if [ "$inherited_count" -eq 0 ]; then
        ui_print "✅ 本次未继承旧配置文件"
    else
        ui_print "🎉 配置继承完成（共 $inherited_count 项）"
    fi
}

inherit_config

ui_print " "
ui_print "✅ 模块刷入完成！"
ui_print "请重启手机生效"
ui_print "=================================="

ui_print "🔄 正在跳转酷安主页..."
(am start -d 'coolmarket://u/29109774' >/dev/null 2>&1) &
ui_print "❤️ 感谢您的支持！"
